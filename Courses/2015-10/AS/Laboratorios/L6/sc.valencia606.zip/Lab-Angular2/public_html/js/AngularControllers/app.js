/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var current = {};
var logged = false;

(function(){
    var aplicacionMundial= angular.module('aplicacionMundial',[]);
    var local = false;
    var service = '';
    if(local)
        service = 'http://localhost:9000/competitor';
    else
        service = 'https://sorteo-mundial.herokuapp.com/competitor';
    
    
    
    aplicacionMundial.directive('toolbar', function(){
        return{
            restrict:'E',
            templateUrl: 'partials/toolbar.html',
            controller:function(){
                this.tab=0;
                this.selectTab=function(setTab){
                    this.tab=setTab;
                };
                this.isSelected=function(tabParam){
                    return this.tab===tabParam;
                };
            },
            controllerAs:'toolbar'
        };
    });

    aplicacionMundial.directive('competitorInfo', function(){
        return{

            restrict:'E',
            templateUrl:'partials/competitor-info.html',
            controller: ['$http','$log',function($http,$log){                    
                if(!logged) {
                    alert("Debe hacer login para ver la información");
                    return;
                }
                var self=this;
                self.competitors=[];
                self.competitor = {};
                self.user = logged;
                $http.get(service).success(function(data){
                    self.competitors=data;
                });
            }],
            controllerAs:'competitorInfo'
        };
        
    
        
        
        /*
        if(isEmpty(current)) {
            return{
            restrict:'E',
            templateUrl:'partials/competitor-login.html',
            controller: ['$http',function($http){
                var self=this;
                self.competitor={};
                this.validate=function(){
                    $http.post(service + '/login', JSON.stringify(self.competitor)).success(function(data){
                        
                        user=data;
                        if(user.username == null) {
                            alert("Credenciales inválidas");
                            self.competitor={}
                            user = {};
                        }
                        else {
                            alert("Bienvenido: " + user.username);
                            alert(JSON.stringify(user));
                            console.log(user);
                            logged = true;
                        }
                        toolbar.tab=0;
                    });
                };
                
            }],
        
            controllerAs:'competitorCtrl2'
        };            
        }
        alert(JSON.stringify(user));
        */

    });
    
    aplicacionMundial.directive('competitorForm', function(){
        
        
        return{
            restrict:'E',
            templateUrl:'partials/competitor-form.html',
            controller: ['$http',function($http){
                var self=this;
                self.competitor={};
                this.addCompetitor=function(){
                    $http.post(service, JSON.stringify(self.competitor)).success(function(data){
                        self.competitor={};
                        
                    });
                };
            }],
            controllerAs:'competitorCtrl'
        };
    });
    
    aplicacionMundial.directive('competitorLogin', function(){
        return{
            restrict:'E',
            templateUrl:'partials/competitor-login.html',
            controller: ['$http',function($http){
                var self=this;
                if(!isEmpty(current)) {
                    alert("Ya se encuentra logueado " + current.username);
                    return;
                }
                self.competitor={};
                this.validate=function(){
                    $http.post(service + '/login', JSON.stringify(self.competitor)).success(function(data){
                        
                        current=data;
                        if(current.username == null) {
                            alert("Credenciales inválidas");
                            self.competitor={}
                            current = {};
                        }
                        else {
                            alert("Bienvenido: " + current.username);
                            logged = true;
                        }
                        toolbar.tab=0;
                    });
                };
                
            }],
        
            controllerAs:'competitorCtrl2'
        };
    });
    
    aplicacionMundial.directive('competitorLogout', function(){
        return{
            restrict:'E',
            templateUrl:'partials/competitor-logout.html',
            controller: ['$http',function($http){
                var self=this;
                self.who = current;
                current = {};
                logged = false;
                
            }],
        
            controllerAs:'competitorCtrl2'
        };
    });

})();

function isEmpty(obj) {
    for(var prop in obj) {
        if(obj.hasOwnProperty(prop))
            return false;
    }

    return true;
}



