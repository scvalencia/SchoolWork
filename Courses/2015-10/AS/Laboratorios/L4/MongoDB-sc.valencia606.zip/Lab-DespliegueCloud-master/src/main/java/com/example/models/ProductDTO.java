/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.models;

import java.util.Calendar;

/**
 *
 * @author scvalencia
 */
public class ProductDTO {
    
    private String name;
 
    private String brand;
    
    private Calendar boughtAt; 

    public ProductDTO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Calendar getBoughtAt() {
        return boughtAt;
    }

    public void setBoughtAt(Calendar boughtAt) {
        this.boughtAt = boughtAt;
    }
    
    
    
}
