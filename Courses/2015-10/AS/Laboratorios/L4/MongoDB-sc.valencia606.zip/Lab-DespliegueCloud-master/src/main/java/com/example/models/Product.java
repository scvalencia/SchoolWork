package com.example.models;
 
import com.sun.istack.NotNull;
import java.io.Serializable;
import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import org.eclipse.persistence.nosql.annotations.DataFormatType;
import org.eclipse.persistence.nosql.annotations.NoSql;

@NoSql(dataFormat=DataFormatType.MAPPED)
@Embeddable
@XmlRootElement
public class Product implements Serializable {
    
    private String name;
 
    private String brand;
 
    @NotNull
    @Column(name = "create_at", updatable = false)
    @Temporal(TemporalType.DATE)
    private Calendar boughtAt = Calendar.getInstance(); 
    
    public Product() {
 
    }

    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }

    public Calendar getBoughtAt() {
        return boughtAt;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setBoughtAt(Calendar boughtAt) {
        this.boughtAt = boughtAt;
    }
    
    
 
    
    
    
 
    
}
