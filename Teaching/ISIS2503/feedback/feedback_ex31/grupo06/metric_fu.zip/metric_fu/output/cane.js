        var graph_title = 'Cane: code quality threshold violations';
        var graph_series = [{name: 'cane', data: [65]}];
        var graph_labels = {"0":"11/8"};
