        var graph_title = 'Rails Best Practices: design problems';
        var graph_series = [{name: 'rails_best_practices', data: [31]}];
        var graph_labels = {"0":"11/8"};
