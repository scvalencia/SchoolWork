        var graph_title = 'Roodi: design problems';
        var graph_series = [{name: 'roodi', data: [9]}];
        var graph_labels = {"0":"11/8"};
