        var graph_title = 'Flay: duplication';
        var graph_series = [{name: 'flay', data: [1501]}];
        var graph_labels = {"0":"11/8"};
