        var graph_title = 'Stats: LOC & LOT';
        var graph_series = [{name: 'LOC', data: [2357]},{name: 'LOT', data: [0]}];
        var graph_labels = {"0":"11/8"};
