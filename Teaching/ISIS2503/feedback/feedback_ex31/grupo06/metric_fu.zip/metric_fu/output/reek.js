        var graph_title = 'Reek: code smells';
        var graph_series = [{name: 'IrresponsibleModule', data: [24]},{name: 'DuplicateMethodCall', data: [81]},{name: 'NestedIterators', data: [18]},{name: 'TooManyStatements', data: [36]},{name: 'UncommunicativeVariableName', data: [55]},{name: 'NilCheck', data: [11]},{name: 'TooManyInstanceVariables', data: [3]},{name: 'ControlParameter', data: [1]},{name: 'RepeatedConditional', data: [1]},{name: 'UnusedParameters', data: [1]}];
        var graph_labels = {"0":"11/8"};
