        var graph_title = 'Flog: code complexity';
        var graph_series = [{name: 'average', data: [13.529763424599023]},{name: 'top 5% average', data: [70.17901012987464]}];
        var graph_labels = {"0":"11/8"};
